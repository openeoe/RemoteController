package com.nanum.exobrain.search.etri;

public class module {
	public module(){
		System.out.println("MODULE1 IS LOADED");
	}
	
	public String QA(String input){
		String output = input+"{java MODULE1 output}";
		return output;

	}
}
